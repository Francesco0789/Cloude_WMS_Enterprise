export interface OrdineListItem {
  ordineVenditaID: number
  numeroOrdine: string
  ragioneSocialeCliente: string
  dataOrdine: string
  dataConsegnaPrevista: string | null
  priorita: number
  stato: OrderStato
  costoTotale: number
  numeroRighe: number
}

export type OrderStato = 'BOZZA' | 'CONFERMATO' | 'IN_PICKING' | 'PRONTO' | 'SPEDITO' | 'CONSEGNATO' | 'ANNULLATO'

export interface GiacenzaItem {
  giacenzaID: number
  articoloID: number
  codiceArticolo: string
  descrizioneArticolo: string
  codiceUbicazione: string
  lottoProduzione: string | null
  dataScadenza: string | null
  quantitaDisponibile: number
  quantitaPrenotata: number
  quantitaTotale: number
  valoreDisponibile: number
  inScadenzaBreve: boolean
}

export interface DashboardKpi {
  ordiniAperti: number
  palletInEntrata: number
  spedzioniOggi: number
  valoreTotaleStock: number
  articoliSottoScortaMinima: number
  articoliInScadenza: number
  saturazioneAree: SaturazioneArea[]
}

export interface SaturazioneArea {
  codiceArea: string
  descrizioneArea: string
  capacitaTotale: number
  capacitaOccupata: number
  percentualeSaturazione: number
}

export interface Spedizione {
  spedizioneID: number
  numeroSpedizione: string
  nomeVettore: string
  dataSpedizione: string | null
  stato: string
  numeroTracking: string | null
  numeroColli: number | null
}

export interface PagedResult<T> {
  items: T[]
  totalCount: number
  page: number
  pageSize: number
  totalPages?: number
}
