import { Routes, Route } from 'react-router-dom'
import { Sidebar } from '@/components/layout/Sidebar'
import { Topbar } from '@/components/layout/Topbar'
import { Dashboard } from '@/features/dashboard/Dashboard'
import { OrdiniPage } from '@/features/orders/OrdiniPage'
import { GiacenzePage } from '@/features/inventory/GiacenzePage'
import { SpedzioniPage } from '@/features/shipments/SpedzioniPage'
import { ReportPage } from '@/features/reports/ReportPage'

const pageMap: Record<string, string> = {
  '/': 'Dashboard',
  '/ordini': 'Ordini vendita',
  '/giacenze': 'Giacenze',
  '/spedizioni': 'Spedizioni',
  '/report': 'Report & KPI',
  '/entrata-merce': 'Entrata merce',
  '/mappa': 'Mappa ubicazioni',
  '/movimentazioni': 'Movimentazioni',
  '/richieste': 'Richieste logistiche',
}

function ComingSoon({ title }: { title: string }) {
  return (
    <div className="flex-1 flex flex-col">
      <Topbar title={title} />
      <div className="flex-1 flex items-center justify-center text-slate-400 text-sm">
        Modulo in sviluppo — connetti il backend API
      </div>
    </div>
  )
}

export default function App() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/ordini" element={<OrdiniPage />} />
          <Route path="/giacenze" element={<GiacenzePage />} />
          <Route path="/spedizioni" element={<SpedzioniPage />} />
          <Route path="/report" element={<ReportPage />} />
          <Route path="/entrata-merce" element={<ComingSoon title="Entrata merce" />} />
          <Route path="/mappa" element={<ComingSoon title="Mappa ubicazioni" />} />
          <Route path="/movimentazioni" element={<ComingSoon title="Movimentazioni" />} />
          <Route path="/richieste" element={<ComingSoon title="Richieste logistiche" />} />
          <Route path="/anagrafiche" element={<ComingSoon title="Anagrafiche" />} />
          <Route path="/impostazioni" element={<ComingSoon title="Impostazioni" />} />
        </Routes>
      </div>
    </div>
  )
}
