import type { DashboardKpi, GiacenzaItem, OrdineListItem, Spedizione } from '@/types'

export const mockKpi: DashboardKpi = {
  ordiniAperti: 47,
  palletInEntrata: 12,
  spedzioniOggi: 8,
  valoreTotaleStock: 842300,
  articoliSottoScortaMinima: 3,
  articoliInScadenza: 7,
  saturazioneAree: [
    { codiceArea: 'A', descrizioneArea: 'Area Picking', capacitaTotale: 200, capacitaOccupata: 164, percentualeSaturazione: 82 },
    { codiceArea: 'B', descrizioneArea: 'Area Stoccaggio', capacitaTotale: 500, capacitaOccupata: 270, percentualeSaturazione: 54 },
    { codiceArea: 'C', descrizioneArea: 'Area Bulk', capacitaTotale: 100, capacitaOccupata: 91, percentualeSaturazione: 91 },
    { codiceArea: 'STG', descrizioneArea: 'Staging', capacitaTotale: 80, capacitaOccupata: 24, percentualeSaturazione: 30 },
    { codiceArea: 'SPC', descrizioneArea: 'Spedizione', capacitaTotale: 60, capacitaOccupata: 40, percentualeSaturazione: 67 },
  ]
}

export const mockOrdini: OrdineListItem[] = [
  { ordineVenditaID: 1, numeroOrdine: 'OV-2024-0892', ragioneSocialeCliente: 'Alfa Srl', dataOrdine: '2024-11-15', dataConsegnaPrevista: '2024-11-20', priorita: 2, stato: 'IN_PICKING', costoTotale: 3420, numeroRighe: 4 },
  { ordineVenditaID: 2, numeroOrdine: 'OV-2024-0891', ragioneSocialeCliente: 'Beta SpA', dataOrdine: '2024-11-14', dataConsegnaPrevista: '2024-11-18', priorita: 1, stato: 'PRONTO', costoTotale: 1850, numeroRighe: 2 },
  { ordineVenditaID: 3, numeroOrdine: 'OV-2024-0890', ragioneSocialeCliente: 'Gamma Ltd', dataOrdine: '2024-11-13', dataConsegnaPrevista: '2024-11-22', priorita: 5, stato: 'CONFERMATO', costoTotale: 7100, numeroRighe: 8 },
  { ordineVenditaID: 4, numeroOrdine: 'OV-2024-0889', ragioneSocialeCliente: 'Delta Sas', dataOrdine: '2024-11-12', dataConsegnaPrevista: '2024-11-17', priorita: 3, stato: 'SPEDITO', costoTotale: 920, numeroRighe: 1 },
  { ordineVenditaID: 5, numeroOrdine: 'OV-2024-0888', ragioneSocialeCliente: 'Epsilon Srl', dataOrdine: '2024-11-11', dataConsegnaPrevista: null, priorita: 8, stato: 'BOZZA', costoTotale: 4200, numeroRighe: 6 },
  { ordineVenditaID: 6, numeroOrdine: 'OV-2024-0887', ragioneSocialeCliente: 'Zeta Corp', dataOrdine: '2024-11-10', dataConsegnaPrevista: '2024-11-15', priorita: 1, stato: 'CONSEGNATO', costoTotale: 680, numeroRighe: 3 },
]

export const mockGiacenze: GiacenzaItem[] = [
  { giacenzaID: 1, articoloID: 1, codiceArticolo: 'ART-001', descrizioneArticolo: 'Prodotto Alpha XL', codiceUbicazione: 'MAG01-A-C01-S02-L3', lottoProduzione: 'LOT-2024-09A', dataScadenza: '2025-09-30', quantitaDisponibile: 280, quantitaPrenotata: 48, quantitaTotale: 328, valoreDisponibile: 8400, inScadenzaBreve: false },
  { giacenzaID: 2, articoloID: 2, codiceArticolo: 'ART-002', descrizioneArticolo: 'Prodotto Beta M', codiceUbicazione: 'MAG01-A-C01-S03-L2', lottoProduzione: 'LOT-2024-09B', dataScadenza: '2024-12-15', quantitaDisponibile: 60, quantitaPrenotata: 0, quantitaTotale: 60, valoreDisponibile: 1800, inScadenzaBreve: true },
  { giacenzaID: 3, articoloID: 3, codiceArticolo: 'ART-003', descrizioneArticolo: 'Componente Gamma', codiceUbicazione: 'MAG01-B-C02-S01-L1', lottoProduzione: null, dataScadenza: null, quantitaDisponibile: 1200, quantitaPrenotata: 200, quantitaTotale: 1400, valoreDisponibile: 24000, inScadenzaBreve: false },
  { giacenzaID: 4, articoloID: 4, codiceArticolo: 'ART-004', descrizioneArticolo: 'Kit Delta Pro', codiceUbicazione: 'MAG01-A-C03-S01-L4', lottoProduzione: 'LOT-2024-10A', dataScadenza: '2025-03-01', quantitaDisponibile: 45, quantitaPrenotata: 10, quantitaTotale: 55, valoreDisponibile: 5850, inScadenzaBreve: false },
]

export const mockSpedizioni: Spedizione[] = [
  { spedizioneID: 1, numeroSpedizione: 'SPE-2024-0156', nomeVettore: 'DHL Express', dataSpedizione: '2024-11-15T09:30:00', stato: 'IN_TRANSITO', numeroTracking: '1Z999AA10123456784', numeroColli: 4 },
  { spedizioneID: 2, numeroSpedizione: 'SPE-2024-0155', nomeVettore: 'GLS Italia', dataSpedizione: '2024-11-15T08:00:00', stato: 'CONSEGNATA', numeroTracking: 'GLS123456789IT', numeroColli: 2 },
  { spedizioneID: 3, numeroSpedizione: 'SPE-2024-0154', nomeVettore: 'BRT', dataSpedizione: null, stato: 'BOZZA', numeroTracking: null, numeroColli: null },
]
