import axios from 'axios'

const USE_MOCK = import.meta.env.VITE_USE_MOCK === 'true'
const API_URL = import.meta.env.VITE_API_URL || '/api/v1'

export const apiClient = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
})

apiClient.interceptors.request.use(config => {
  const token = localStorage.getItem('wms_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

apiClient.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('wms_token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export const isMockMode = () => USE_MOCK

// Simula latenza di rete per mock realistico
export const mockDelay = (ms = 350) => new Promise(r => setTimeout(r, ms))
