import { useQuery } from '@tanstack/react-query'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { Download } from 'lucide-react'
import { Topbar } from '@/components/layout/Topbar'
import { mockKpi, mockDelay, isMockMode, apiClient } from '@/lib/api'
import type { DashboardKpi } from '@/types'

async function fetchKpi(): Promise<DashboardKpi> {
  if (isMockMode()) { await mockDelay(); return mockKpi }
  const { data } = await apiClient.get<DashboardKpi>('/reports/dashboard-kpi')
  return data
}

export function ReportPage() {
  const { data: kpi } = useQuery({ queryKey: ['dashboard-kpi'], queryFn: fetchKpi })

  return (
    <div className="flex-1 flex flex-col">
      <Topbar title="Report & KPI" subtitle="Analisi e statistiche logistiche" />
      <div className="p-6 flex-1 overflow-auto">
        <div className="flex justify-end mb-4 gap-2">
          <button className="btn-secondary flex items-center gap-1.5"><Download size={14}/> Esporta CSV</button>
          <button className="btn-secondary flex items-center gap-1.5"><Download size={14}/> Esporta PDF</button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-4">Saturazione per area</h3>
            {kpi && (
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={kpi.saturazioneAree}>
                  <XAxis dataKey="codiceArea" tick={{ fontSize: 11 }} />
                  <YAxis tickFormatter={v => `${v}%`} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={v => [`${v}%`, 'Saturazione']} />
                  <Bar dataKey="percentualeSaturazione" fill="#4c6ef5" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-4">KPI principali</h3>
            {kpi && (
              <div className="space-y-3 mt-2">
                {[
                  { label: 'Ordini aperti', value: kpi.ordiniAperti, unit: 'ordini' },
                  { label: 'Articoli in scadenza', value: kpi.articoliInScadenza, unit: 'articoli' },
                  { label: 'Sotto scorta minima', value: kpi.articoliSottoScortaMinima, unit: 'articoli' },
                  { label: 'Valore stock totale', value: `€ ${(kpi.valoreTotaleStock/1000).toFixed(1)}K`, unit: '' },
                ].map(row => (
                  <div key={row.label} className="flex items-center justify-between py-2 border-b border-slate-100">
                    <span className="text-sm text-slate-600">{row.label}</span>
                    <span className="text-sm font-semibold text-slate-800">{row.value} {row.unit}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
