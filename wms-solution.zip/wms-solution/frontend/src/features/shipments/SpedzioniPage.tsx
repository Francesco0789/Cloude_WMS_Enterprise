import { useQuery } from '@tanstack/react-query'
import { Truck, Plus } from 'lucide-react'
import { Topbar } from '@/components/layout/Topbar'
import { mockSpedizioni, mockDelay, isMockMode, apiClient } from '@/lib/api'
import type { Spedizione } from '@/types'

async function fetchSpedizioni(): Promise<Spedizione[]> {
  if (isMockMode()) { await mockDelay(); return mockSpedizioni }
  const { data } = await apiClient.get<{ items: Spedizione[] }>('/shipments')
  return data.items
}

const statoColors: Record<string, string> = {
  BOZZA: 'bg-slate-100 text-slate-600',
  PRONTA: 'bg-blue-100 text-blue-700',
  IN_TRANSITO: 'bg-amber-100 text-amber-700',
  CONSEGNATA: 'bg-emerald-100 text-emerald-700',
  PROBLEMA: 'bg-red-100 text-red-700',
}

export function SpedzioniPage() {
  const { data: spedizioni = [], isLoading } = useQuery({ queryKey: ['spedizioni'], queryFn: fetchSpedizioni })
  return (
    <div className="flex-1 flex flex-col">
      <Topbar title="Spedizioni" subtitle="Gestione vettori e tracking" />
      <div className="p-6 flex-1 overflow-auto">
        <div className="flex justify-end mb-4">
          <button className="btn-primary flex items-center gap-1.5"><Plus size={14}/> Nuova spedizione</button>
        </div>
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50">
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">N° Spedizione</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Vettore</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Data</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Tracking</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Colli</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Stato</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? Array.from({length:3}).map((_,i) => (
                <tr key={i}>{Array.from({length:6}).map((_,j) => (
                  <td key={j} className="px-4 py-3"><div className="h-4 bg-slate-100 rounded animate-pulse"/></td>
                ))}</tr>
              )) : spedizioni.map(s => (
                <tr key={s.spedizioneID} className="border-b border-slate-50 hover:bg-slate-50/60 cursor-pointer">
                  <td className="px-4 py-3 font-mono text-xs">{s.numeroSpedizione}</td>
                  <td className="px-4 py-3 font-medium text-slate-800">{s.nomeVettore}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{s.dataSpedizione ? new Date(s.dataSpedizione).toLocaleDateString('it-IT') : '—'}</td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-500">{s.numeroTracking ?? '—'}</td>
                  <td className="px-4 py-3 text-slate-700">{s.numeroColli ?? '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`badge ${statoColors[s.stato] ?? 'bg-slate-100 text-slate-600'}`}>
                      {s.stato.replace('_',' ')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
