import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Search, AlertTriangle } from 'lucide-react'
import { Topbar } from '@/components/layout/Topbar'
import { mockGiacenze, mockDelay, isMockMode, apiClient } from '@/lib/api'
import type { GiacenzaItem } from '@/types'

async function fetchGiacenze(): Promise<GiacenzaItem[]> {
  if (isMockMode()) { await mockDelay(); return mockGiacenze }
  const { data } = await apiClient.get<{ items: GiacenzaItem[] }>('/inventory')
  return data.items
}

export function GiacenzePage() {
  const [search, setSearch] = useState('')
  const { data: giacenze = [], isLoading } = useQuery({ queryKey: ['giacenze'], queryFn: fetchGiacenze })

  const filtered = giacenze.filter(g =>
    g.codiceArticolo.toLowerCase().includes(search.toLowerCase()) ||
    g.descrizioneArticolo.toLowerCase().includes(search.toLowerCase()) ||
    g.codiceUbicazione.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="flex-1 flex flex-col">
      <Topbar title="Giacenze" subtitle="Stock per articolo e ubicazione" />
      <div className="p-6 flex-1 overflow-auto">
        <div className="flex items-center gap-3 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className="input-field pl-8" placeholder="Articolo, codice, ubicazione..."
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <span className="text-xs text-slate-500 ml-auto">{filtered.length} righe</span>
        </div>

        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50">
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Articolo</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Ubicazione</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Lotto</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Scadenza</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Disponibile</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Prenotata</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">€ Valore</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({length:4}).map((_,i) => (
                  <tr key={i} className="border-b border-slate-50">
                    {Array.from({length:7}).map((_,j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-slate-100 rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : filtered.map(g => (
                <tr key={g.giacenzaID} className={`border-b border-slate-50 hover:bg-slate-50/60 transition-colors ${g.inScadenzaBreve ? 'bg-amber-50/40' : ''}`}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      {g.inScadenzaBreve && <AlertTriangle size={12} className="text-amber-500 flex-shrink-0" />}
                      <div>
                        <p className="font-mono text-xs text-slate-500">{g.codiceArticolo}</p>
                        <p className="font-medium text-slate-800 text-xs">{g.descrizioneArticolo}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-600">{g.codiceUbicazione}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{g.lottoProduzione ?? '—'}</td>
                  <td className="px-4 py-3 text-xs">
                    {g.dataScadenza
                      ? <span className={g.inScadenzaBreve ? 'text-amber-700 font-medium' : 'text-slate-500'}>{g.dataScadenza}</span>
                      : <span className="text-slate-300">—</span>}
                  </td>
                  <td className="px-4 py-3 text-right font-semibold text-slate-800">{g.quantitaDisponibile.toLocaleString('it-IT')}</td>
                  <td className="px-4 py-3 text-right text-slate-500">{g.quantitaPrenotata.toLocaleString('it-IT')}</td>
                  <td className="px-4 py-3 text-right text-slate-700">
                    € {g.valoreDisponibile.toLocaleString('it-IT', {minimumFractionDigits:0})}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
