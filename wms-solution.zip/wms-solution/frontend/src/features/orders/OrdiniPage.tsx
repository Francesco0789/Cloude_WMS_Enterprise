import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Search, Plus, ChevronUp, ChevronDown } from 'lucide-react'
import { Topbar } from '@/components/layout/Topbar'
import { mockOrdini, mockDelay, isMockMode, apiClient } from '@/lib/api'
import type { OrdineListItem, PagedResult } from '@/types'

async function fetchOrdini(stato?: string): Promise<OrdineListItem[]> {
  if (isMockMode()) {
    await mockDelay()
    return stato ? mockOrdini.filter(o => o.stato === stato) : mockOrdini
  }
  const { data } = await apiClient.get<PagedResult<OrdineListItem>>('/sales-orders', { params: { stato } })
  return data.items
}

function StatoBadge({ stato }: { stato: string }) {
  const cls = `status-${stato.toLowerCase().replace('_','-')}` as string
  const labels: Record<string,string> = {
    BOZZA:'Bozza', CONFERMATO:'Confermato', IN_PICKING:'In picking',
    PRONTO:'Pronto', SPEDITO:'Spedito', CONSEGNATO:'Consegnato', ANNULLATO:'Annullato'
  }
  return <span className={cls}>{labels[stato] ?? stato}</span>
}

const STATI = ['', 'BOZZA','CONFERMATO','IN_PICKING','PRONTO','SPEDITO','CONSEGNATO','ANNULLATO']

export function OrdiniPage() {
  const [statoFilter, setStatoFilter] = useState('')
  const [search, setSearch] = useState('')

  const { data: ordini = [], isLoading } = useQuery({
    queryKey: ['ordini', statoFilter],
    queryFn: () => fetchOrdini(statoFilter || undefined)
  })

  const filtered = ordini.filter(o =>
    o.numeroOrdine.toLowerCase().includes(search.toLowerCase()) ||
    o.ragioneSocialeCliente.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="flex-1 flex flex-col">
      <Topbar title="Ordini vendita" subtitle={`${filtered.length} ordini`} />
      <div className="p-6 flex-1 overflow-auto">

        {/* Toolbar */}
        <div className="flex items-center gap-3 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className="input-field pl-8" placeholder="Cerca ordine o cliente..."
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="input-field w-44" value={statoFilter} onChange={e => setStatoFilter(e.target.value)}>
            <option value="">Tutti gli stati</option>
            {STATI.filter(Boolean).map(s => <option key={s} value={s}>{s.replace('_',' ')}</option>)}
          </select>
          <button className="btn-primary flex items-center gap-1.5 ml-auto">
            <Plus size={14} /> Nuovo ordine
          </button>
        </div>

        {/* Table */}
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50">
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">N° Ordine</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Cliente</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Data</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Consegna</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Prio</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Stato</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">€ Totale</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Righe</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({length:5}).map((_,i) => (
                  <tr key={i} className="border-b border-slate-50">
                    {Array.from({length:8}).map((_,j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-slate-100 rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : filtered.map(o => (
                <tr key={o.ordineVenditaID} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors cursor-pointer">
                  <td className="px-4 py-3 font-mono text-xs text-slate-700">{o.numeroOrdine}</td>
                  <td className="px-4 py-3 font-medium text-slate-800">{o.ragioneSocialeCliente}</td>
                  <td className="px-4 py-3 text-slate-500 text-xs">{o.dataOrdine}</td>
                  <td className="px-4 py-3 text-slate-500 text-xs">{o.dataConsegnaPrevista ?? '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-bold ${o.priorita <= 2 ? 'text-red-600' : o.priorita <= 5 ? 'text-amber-600' : 'text-slate-400'}`}>
                      P{o.priorita}
                    </span>
                  </td>
                  <td className="px-4 py-3"><StatoBadge stato={o.stato} /></td>
                  <td className="px-4 py-3 text-right font-medium text-slate-800">
                    € {o.costoTotale.toLocaleString('it-IT', {minimumFractionDigits:2})}
                  </td>
                  <td className="px-4 py-3 text-right text-slate-500">{o.numeroRighe}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!isLoading && filtered.length === 0 && (
            <div className="text-center py-12 text-slate-400 text-sm">Nessun ordine trovato</div>
          )}
        </div>
      </div>
    </div>
  )
}
