import { useQuery } from '@tanstack/react-query'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { Package, ShoppingCart, Truck, TrendingUp, AlertTriangle, Clock } from 'lucide-react'
import { Topbar } from '@/components/layout/Topbar'
import { mockKpi, mockDelay, isMockMode, apiClient } from '@/lib/api'
import type { DashboardKpi } from '@/types'

async function fetchKpi(): Promise<DashboardKpi> {
  if (isMockMode()) { await mockDelay(); return mockKpi }
  const { data } = await apiClient.get<DashboardKpi>('/reports/dashboard-kpi')
  return data
}

function KpiCard({ icon: Icon, label, value, sub, color }: {
  icon: React.ElementType; label: string; value: string | number; sub?: string; color: string
}) {
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between mb-3">
        <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{label}</p>
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${color}`}>
          <Icon size={15} />
        </div>
      </div>
      <p className="text-2xl font-semibold text-slate-900 leading-none">{value}</p>
      {sub && <p className="text-xs text-slate-400 mt-1.5">{sub}</p>}
    </div>
  )
}

const BAR_COLORS = ['#10b981','#3b82f6','#ef4444','#f59e0b','#8b5cf6']

export function Dashboard() {
  const { data: kpi, isLoading } = useQuery({ queryKey: ['dashboard-kpi'], queryFn: fetchKpi, refetchInterval: 60_000 })

  return (
    <div className="flex-1 flex flex-col">
      <Topbar title="Dashboard" subtitle="Panoramica magazzino in tempo reale" />
      <div className="flex-1 p-6 overflow-auto">

        {isLoading ? (
          <div className="grid grid-cols-4 gap-4 mb-6 animate-pulse">
            {Array.from({length:4}).map((_,i) => (
              <div key={i} className="card p-5 h-24 bg-slate-100" />
            ))}
          </div>
        ) : kpi ? (
          <>
            {/* KPI Row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <KpiCard icon={ShoppingCart} label="Ordini aperti" value={kpi.ordiniAperti}
                sub="Da evadere" color="bg-blue-50 text-blue-600" />
              <KpiCard icon={Package} label="Pallet entrati oggi" value={kpi.palletInEntrata}
                sub="2 in attesa QC" color="bg-emerald-50 text-emerald-600" />
              <KpiCard icon={Truck} label="Spedizioni oggi" value={kpi.spedzioniOggi}
                sub="6 confermate" color="bg-violet-50 text-violet-600" />
              <KpiCard icon={TrendingUp} label="Valore stock"
                value={`€ ${(kpi.valoreTotaleStock / 1000).toFixed(0)}K`}
                sub="Aggiornato ora" color="bg-amber-50 text-amber-600" />
            </div>

            {/* Alerts Row */}
            {(kpi.articoliInScadenza > 0 || kpi.articoliSottoScortaMinima > 0) && (
              <div className="flex gap-3 mb-6">
                {kpi.articoliInScadenza > 0 && (
                  <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-lg px-4 py-2.5 text-sm text-amber-800">
                    <Clock size={14} />
                    <span><strong>{kpi.articoliInScadenza}</strong> articoli in scadenza entro 30 giorni</span>
                  </div>
                )}
                {kpi.articoliSottoScortaMinima > 0 && (
                  <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg px-4 py-2.5 text-sm text-red-800">
                    <AlertTriangle size={14} />
                    <span><strong>{kpi.articoliSottoScortaMinima}</strong> articoli sotto scorta minima</span>
                  </div>
                )}
              </div>
            )}

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Saturazione aree */}
              <div className="card p-5">
                <h3 className="text-sm font-semibold text-slate-800 mb-4">Saturazione aree magazzino</h3>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={kpi.saturazioneAree} layout="vertical" margin={{ left: 0, right: 30 }}>
                    <XAxis type="number" domain={[0, 100]} tickFormatter={v => `${v}%`} tick={{ fontSize: 11 }} />
                    <YAxis type="category" dataKey="descrizioneArea" tick={{ fontSize: 11 }} width={90} />
                    <Tooltip formatter={(v) => [`${v}%`, 'Saturazione']} />
                    <Bar dataKey="percentualeSaturazione" radius={[0, 4, 4, 0]}>
                      {kpi.saturazioneAree.map((entry, i) => (
                        <Cell key={i} fill={entry.percentualeSaturazione > 85 ? '#ef4444' : entry.percentualeSaturazione > 65 ? '#f59e0b' : '#10b981'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Info extra */}
              <div className="card p-5">
                <h3 className="text-sm font-semibold text-slate-800 mb-4">Riepilogo operativo</h3>
                <div className="space-y-3">
                  {kpi.saturazioneAree.map((area, i) => (
                    <div key={area.codiceArea} className="flex items-center gap-3">
                      <span className="text-xs text-slate-500 w-28 truncate">{area.descrizioneArea}</span>
                      <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all"
                          style={{
                            width: `${area.percentualeSaturazione}%`,
                            background: BAR_COLORS[i % BAR_COLORS.length]
                          }} />
                      </div>
                      <span className="text-xs font-medium text-slate-700 w-10 text-right">
                        {area.percentualeSaturazione}%
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 gap-3 text-xs text-slate-500">
                  <div>
                    <p className="font-medium text-slate-700 text-base">{kpi.saturazioneAree.reduce((a,b) => a + b.capacitaOccupata,0)}</p>
                    <p>Ubicazioni occupate</p>
                  </div>
                  <div>
                    <p className="font-medium text-slate-700 text-base">{kpi.saturazioneAree.reduce((a,b) => a + b.capacitaTotale,0)}</p>
                    <p>Capacità totale</p>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </div>
  )
}
