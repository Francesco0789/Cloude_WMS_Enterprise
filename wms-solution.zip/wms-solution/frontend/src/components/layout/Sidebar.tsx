import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, Package, ShoppingCart, Truck, MapPin,
  BarChart3, ArrowLeftRight, ClipboardList, Users, Settings, Warehouse
} from 'lucide-react'

const nav = [
  { section: 'Operativo', items: [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/entrata-merce', label: 'Entrata merce', icon: Package },
    { to: '/ordini', label: 'Ordini vendita', icon: ShoppingCart },
  ]},
  { section: 'Magazzino', items: [
    { to: '/mappa', label: 'Mappa ubicazioni', icon: MapPin },
    { to: '/giacenze', label: 'Giacenze', icon: Warehouse },
    { to: '/movimentazioni', label: 'Movimentazioni', icon: ArrowLeftRight },
  ]},
  { section: 'Logistica', items: [
    { to: '/richieste', label: 'Richieste logistiche', icon: ClipboardList },
    { to: '/spedizioni', label: 'Spedizioni', icon: Truck },
  ]},
  { section: 'Analisi', items: [
    { to: '/report', label: 'Report & KPI', icon: BarChart3 },
  ]},
  { section: 'Sistema', items: [
    { to: '/anagrafiche', label: 'Anagrafiche', icon: Users },
    { to: '/impostazioni', label: 'Impostazioni', icon: Settings },
  ]},
]

export function Sidebar() {
  return (
    <aside className="w-56 min-h-screen bg-slate-900 flex flex-col">
      <div className="px-4 py-5 border-b border-slate-700/60">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-wms-500 flex items-center justify-center">
            <Warehouse size={14} className="text-white" />
          </div>
          <div>
            <p className="text-white text-sm font-semibold leading-tight">WMS Enterprise</p>
            <p className="text-slate-500 text-[10px] leading-tight">v1.0 · Mag. Centrale</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 py-3 overflow-y-auto">
        {nav.map(group => (
          <div key={group.section} className="mb-4">
            <p className="px-4 mb-1 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
              {group.section}
            </p>
            {group.items.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-2.5 px-4 py-2 mx-2 rounded-lg text-sm transition-colors ${
                    isActive
                      ? 'bg-wms-600/20 text-wms-400 font-medium'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`
                }
              >
                <item.icon size={15} />
                {item.label}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      <div className="px-4 py-3 border-t border-slate-700/60">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-full bg-wms-600 flex items-center justify-center text-white text-xs font-medium">
            MR
          </div>
          <div>
            <p className="text-slate-300 text-xs font-medium">Mario Rossi</p>
            <p className="text-slate-500 text-[10px]">Responsabile logistica</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
