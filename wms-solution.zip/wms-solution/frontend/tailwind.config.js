/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        wms: {
          50:  '#f0f4ff',
          100: '#dbe4ff',
          200: '#bac8ff',
          500: '#4c6ef5',
          600: '#3b5bdb',
          700: '#2f4ac4',
          900: '#1a2f8f',
        }
      },
      fontFamily: {
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      }
    }
  },
  plugins: []
}
