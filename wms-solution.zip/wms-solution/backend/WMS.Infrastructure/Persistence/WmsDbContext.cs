using Microsoft.EntityFrameworkCore;
using WMS.Domain.Entities;

namespace WMS.Infrastructure.Persistence;

public class WmsDbContext(DbContextOptions<WmsDbContext> options) : DbContext(options)
{
    // Warehouse
    public DbSet<Magazzino> Magazzini => Set<Magazzino>();
    public DbSet<Area> Aree => Set<Area>();
    public DbSet<Corsia> Corsie => Set<Corsia>();
    public DbSet<Scaffale> Scaffali => Set<Scaffale>();
    public DbSet<Livello> Livelli => Set<Livello>();
    public DbSet<Ubicazione> Ubicazioni => Set<Ubicazione>();

    // Inventory
    public DbSet<Articolo> Articoli => Set<Articolo>();
    public DbSet<Giacenza> Giacenze => Set<Giacenza>();
    public DbSet<Movimento> Movimenti => Set<Movimento>();
    public DbSet<Pallet> Pallet => Set<Pallet>();
    public DbSet<Collo> Colli => Set<Collo>();

    // Orders
    public DbSet<Fornitore> Fornitori => Set<Fornitore>();
    public DbSet<Cliente> Clienti => Set<Cliente>();
    public DbSet<OrdineVendita> OrdiniVendita => Set<OrdineVendita>();
    public DbSet<RigaOrdineVendita> RigheOrdiniVendita => Set<RigaOrdineVendita>();
    public DbSet<EntrataMerce> EntrateM => Set<EntrataMerce>();

    // Shipping
    public DbSet<Vettore> Vettori => Set<Vettore>();
    public DbSet<Spedizione> Spedizioni => Set<Spedizione>();
    public DbSet<RigaSpedizione> RigheSpedizioni => Set<RigaSpedizione>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.HasDefaultSchema("dbo");
        mb.ApplyConfigurationsFromAssembly(typeof(WmsDbContext).Assembly);

        // Unique constraints
        mb.Entity<Magazzino>().HasIndex(x => x.Codice).IsUnique();
        mb.Entity<Articolo>().HasIndex(x => x.Codice).IsUnique();
        mb.Entity<Ubicazione>().HasIndex(x => x.Codice).IsUnique();
        mb.Entity<Vettore>().HasIndex(x => x.Codice).IsUnique();
        mb.Entity<OrdineVendita>().HasIndex(x => x.NumeroOrdine).IsUnique();

        // Giacenza unique (articolo + ubicazione + lotto + scadenza)
        mb.Entity<Giacenza>().HasIndex(x => new
        {
            x.ArticoloID, x.UbicazioneID, x.LottoProduzione, x.DataScadenza
        }).IsUnique();

        // Decimal precision
        mb.Entity<Giacenza>(e => {
            e.Property(x => x.QuantitaDisponibile).HasPrecision(14, 4);
            e.Property(x => x.QuantitaPrenotata).HasPrecision(14, 4);
        });
        mb.Entity<Movimento>(e => {
            e.Property(x => x.Quantita).HasPrecision(14, 4);
        });
        mb.Entity<OrdineVendita>(e => {
            e.Property(x => x.CostoSpedizione).HasPrecision(10, 2);
            e.Property(x => x.ScontoGlobale).HasPrecision(5, 2);
        });
        mb.Entity<RigaOrdineVendita>(e => {
            e.Property(x => x.QuantitaOrdinata).HasPrecision(10, 3);
            e.Property(x => x.PrezzoUnitario).HasPrecision(12, 4);
            e.Property(x => x.Sconto).HasPrecision(5, 2);
            e.Ignore(x => x.ImportoRiga); // computed in C#
        });
        mb.Entity<Articolo>(e => {
            e.Property(x => x.CostoUnitario).HasPrecision(12, 4);
            e.Property(x => x.PrezzoVendita).HasPrecision(12, 4);
        });

        // Ignore computed props
        mb.Entity<OrdineVendita>().Ignore(x => x.ImponibileRighe).Ignore(x => x.CostoTotale);
        mb.Entity<Giacenza>().Ignore(x => x.QuantitaTotale);

        base.OnModelCreating(mb);
    }
}
