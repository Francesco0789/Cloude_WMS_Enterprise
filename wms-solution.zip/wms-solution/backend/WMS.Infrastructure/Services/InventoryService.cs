using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using WMS.Domain.Interfaces;
using WMS.Infrastructure.Persistence;
using WMS.Shared.Exceptions;

namespace WMS.Infrastructure.Services;

public class InventoryService(WmsDbContext db) : IInventoryService
{
    public async Task<int> ScaricoGiacenzaAsync(int articoloId, int ubicazioneId, decimal quantita,
        string? lotto = null, string? documentoRif = null, string? tipoDoc = null,
        string? operatore = null, CancellationToken ct = default)
    {
        var esito = new SqlParameter("@Esito", System.Data.SqlDbType.Int)
        {
            Direction = System.Data.ParameterDirection.Output
        };

        await db.Database.ExecuteSqlRawAsync(
            "EXEC inv.sp_ScaricoGiacenza @ArticoloID, @UbicazioneID, @Quantita, " +
            "@LottoProduzione, @DocumentoRif, @TipoDocumento, @Operatore, @Esito OUTPUT",
            new SqlParameter("@ArticoloID", articoloId),
            new SqlParameter("@UbicazioneID", ubicazioneId),
            new SqlParameter("@Quantita", quantita),
            new SqlParameter("@LottoProduzione", (object?)lotto ?? DBNull.Value),
            new SqlParameter("@DocumentoRif", (object?)documentoRif ?? DBNull.Value),
            new SqlParameter("@TipoDocumento", (object?)tipoDoc ?? DBNull.Value),
            new SqlParameter("@Operatore", (object?)operatore ?? DBNull.Value),
            esito);

        var result = (int)esito.Value;
        if (result == -1)
            throw new InsufficientStockException(articoloId, quantita, 0);

        return result;
    }

    public async Task CaricGiacenzaAsync(int articoloId, int ubicazioneId, decimal quantita,
        string? lotto = null, DateOnly? dataScadenza = null, string? documentoRif = null,
        string? tipoDoc = null, string? operatore = null, CancellationToken ct = default)
    {
        await db.Database.ExecuteSqlRawAsync(
            "EXEC inv.sp_CaricGiacenza @ArticoloID, @UbicazioneID, @Quantita, " +
            "@LottoProduzione, @DataScadenza, @DocumentoRif, @TipoDocumento, @Operatore",
            new SqlParameter("@ArticoloID", articoloId),
            new SqlParameter("@UbicazioneID", ubicazioneId),
            new SqlParameter("@Quantita", quantita),
            new SqlParameter("@LottoProduzione", (object?)lotto ?? DBNull.Value),
            new SqlParameter("@DataScadenza", dataScadenza.HasValue ? (object)dataScadenza.Value.ToDateTime(TimeOnly.MinValue) : DBNull.Value),
            new SqlParameter("@DocumentoRif", (object?)documentoRif ?? DBNull.Value),
            new SqlParameter("@TipoDocumento", (object?)tipoDoc ?? DBNull.Value),
            new SqlParameter("@Operatore", (object?)operatore ?? DBNull.Value));
    }
}
