using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WMS.Application.Reports.Dtos;
using WMS.Infrastructure.Persistence;

namespace WMS.API.Controllers;

[ApiController]
[Route("api/v1/reports")]
[Authorize]
public class ReportsController(WmsDbContext db) : ControllerBase
{
    [HttpGet("dashboard-kpi")]
    public async Task<IActionResult> GetDashboardKpi()
    {
        var ordiniAperti = await db.OrdiniVendita
            .CountAsync(o => o.Stato == "CONFERMATO" || o.Stato == "IN_PICKING");

        var palletInEntrata = await db.Pallet
            .CountAsync(p => p.Stato == "DISPONIBILE" && p.DataCreazione.Date == DateTime.Today);

        var spedzioniOggi = await db.Spedizioni
            .CountAsync(s => s.DataSpedizione.HasValue && s.DataSpedizione.Value.Date == DateTime.Today);

        var valoreStock = await db.Giacenze
            .Include(g => g.Articolo)
            .SumAsync(g => g.QuantitaDisponibile * g.Articolo.CostoUnitario);

        var articoliScadenza = await db.Giacenze
            .CountAsync(g => g.DataScadenza != null &&
                g.DataScadenza.Value < DateOnly.FromDateTime(DateTime.Today.AddDays(30)));

        var kpi = new DashboardKpiDto(
            ordiniAperti, palletInEntrata, spedzioniOggi,
            valoreStock, 0, articoliScadenza,
            new List<SaturazioneAreaDto>());

        return Ok(kpi);
    }

    [HttpGet("inventory-kpi")]
    public async Task<IActionResult> GetInventoryKpi(
        [FromQuery] int? magazzinoId, [FromQuery] bool soloScadenza = false,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
    {
        var query = db.Giacenze
            .Include(g => g.Articolo)
            .Include(g => g.Ubicazione).ThenInclude(u => u.Livello)
                .ThenInclude(l => l.Scaffale).ThenInclude(s => s.Corsia)
                .ThenInclude(c => c.Area).ThenInclude(a => a.Magazzino)
            .Where(g => g.QuantitaDisponibile + g.QuantitaPrenotata > 0)
            .AsQueryable();

        if (soloScadenza)
            query = query.Where(g => g.DataScadenza != null &&
                g.DataScadenza.Value < DateOnly.FromDateTime(DateTime.Today.AddDays(30)));

        var total = await query.CountAsync();
        var items = await query
            .Skip((page - 1) * pageSize).Take(pageSize)
            .Select(g => new KpiGiacenzeDto(
                g.Articolo.Codice, g.Articolo.Descrizione,
                g.Ubicazione.Livello.Scaffale.Corsia.Area.Magazzino.Codice,
                g.Ubicazione.Codice, g.LottoProduzione, g.DataScadenza,
                g.QuantitaDisponibile, g.QuantitaPrenotata,
                g.QuantitaDisponibile * g.Articolo.CostoUnitario,
                g.DataScadenza != null && g.DataScadenza.Value < DateOnly.FromDateTime(DateTime.Today.AddDays(30))))
            .ToListAsync();

        return Ok(new { items, totalCount = total, page, pageSize });
    }
}
