using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WMS.Application.Orders.Dtos;
using WMS.Domain.Entities;
using WMS.Infrastructure.Persistence;
using WMS.Shared.Constants;
using WMS.Shared.Exceptions;

namespace WMS.API.Controllers;

[ApiController]
[Route("api/v1/sales-orders")]
[Authorize]
public class OrdersController(WmsDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetOrdini(
        [FromQuery] string? stato, [FromQuery] int? clienteId,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 30)
    {
        var query = db.OrdiniVendita
            .Include(o => o.Cliente)
            .Include(o => o.Righe)
            .AsQueryable();

        if (!string.IsNullOrEmpty(stato)) query = query.Where(o => o.Stato == stato.ToUpper());
        if (clienteId.HasValue) query = query.Where(o => o.ClienteID == clienteId);

        var total = await query.CountAsync();
        var items = await query
            .OrderByDescending(o => o.DataOrdine).ThenBy(o => o.Priorita)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .Select(o => new OrdineListItemDto(
                o.OrdineVenditaID, o.NumeroOrdine, o.Cliente.RagioneSociale,
                o.DataOrdine, o.DataConsegnaPrevista, o.Priorita, o.Stato,
                o.Righe.Sum(r => r.QuantitaOrdinata * r.PrezzoUnitario * (1 - r.Sconto / 100))
                    * (1 - o.ScontoGlobale / 100) + o.CostoSpedizione,
                o.Righe.Count))
            .ToListAsync();

        return Ok(new { items, totalCount = total, page, pageSize });
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetOrdine(int id)
    {
        var o = await db.OrdiniVendita
            .Include(x => x.Cliente)
            .Include(x => x.Righe).ThenInclude(r => r.Articolo)
            .FirstOrDefaultAsync(x => x.OrdineVenditaID == id);

        if (o is null) return NotFound(new { code = "NOT_FOUND", message = $"Ordine {id} non trovato" });

        var dto = new OrdineVenditaDto(
            o.OrdineVenditaID, o.NumeroOrdine, o.ClienteID, o.Cliente.RagioneSociale,
            o.DataOrdine, o.DataConsegnaPrevista, o.Priorita, o.Stato,
            o.IndirizzoSpedizione,
            o.Righe.Sum(r => r.QuantitaOrdinata * r.PrezzoUnitario * (1 - r.Sconto / 100)),
            o.CostoSpedizione, o.ScontoGlobale,
            o.Righe.Sum(r => r.QuantitaOrdinata * r.PrezzoUnitario * (1 - r.Sconto / 100))
                * (1 - o.ScontoGlobale / 100) + o.CostoSpedizione,
            o.Righe.Select(r => new RigaOrdineVenditaDto(
                r.RigaOrdineVenditaID, r.ArticoloID, r.Articolo.Codice, r.Articolo.Descrizione,
                r.QuantitaOrdinata, r.QuantitaPrelevata, r.PrezzoUnitario, r.Sconto,
                r.QuantitaOrdinata * r.PrezzoUnitario * (1 - r.Sconto / 100), r.StatoRiga)).ToList());

        return Ok(dto);
    }

    [HttpPost]
    [Authorize(Roles = $"{Roles.Admin},{Roles.ResponsabileLogistica}")]
    public async Task<IActionResult> CreaOrdine([FromBody] CreaOrdineVenditaCommand cmd)
    {
        var numero = $"OV-{DateTime.Today:yyyy}-{await db.OrdiniVendita.CountAsync() + 1:D4}";

        var ordine = new OrdineVendita
        {
            NumeroOrdine = numero,
            ClienteID = cmd.ClienteID,
            DataOrdine = DateOnly.FromDateTime(DateTime.Today),
            DataConsegnaPrevista = cmd.DataConsegnaPrevista,
            Priorita = cmd.Priorita,
            IndirizzoSpedizione = cmd.IndirizzoSpedizione,
            Note = cmd.Note,
            CostoSpedizione = cmd.CostoSpedizione,
            ScontoGlobale = cmd.ScontoGlobale,
            Stato = OrderStates.Bozza,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
            CreatedBy = User.Identity?.Name,
            Righe = cmd.Righe.Select(r => new RigaOrdineVendita
            {
                ArticoloID = r.ArticoloID,
                QuantitaOrdinata = r.QuantitaOrdinata,
                PrezzoUnitario = r.PrezzoUnitario,
                Sconto = r.Sconto,
                StatoRiga = "APERTA"
            }).ToList()
        };

        db.OrdiniVendita.Add(ordine);
        await db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetOrdine), new { id = ordine.OrdineVenditaID },
            new { id = ordine.OrdineVenditaID, numeroOrdine = numero });
    }

    [HttpPost("{id}/confirm")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.ResponsabileLogistica}")]
    public async Task<IActionResult> ConfermaOrdine(int id)
    {
        var o = await db.OrdiniVendita.FindAsync(id);
        if (o is null) return NotFound();
        if (o.Stato != OrderStates.Bozza)
            return BadRequest(new { message = "Solo ordini in bozza possono essere confermati" });

        o.Stato = OrderStates.Confermato;
        o.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return Ok(new { stato = o.Stato });
    }

    [HttpPut("{id}/status")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.ResponsabileLogistica}")]
    public async Task<IActionResult> AggiornaStato(int id, [FromBody] string nuovoStato)
    {
        var o = await db.OrdiniVendita.FindAsync(id);
        if (o is null) return NotFound();
        o.Stato = nuovoStato.ToUpper();
        o.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return Ok(new { stato = o.Stato });
    }
}
