using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WMS.Application.Inventory.Dtos;
using WMS.Domain.Interfaces;
using WMS.Infrastructure.Persistence;
using WMS.Shared.Constants;
using WMS.Shared.Exceptions;

namespace WMS.API.Controllers;

[ApiController]
[Route("api/v1/inventory")]
[Authorize]
public class InventoryController(WmsDbContext db, IInventoryService inventoryService) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetGiacenze(
        [FromQuery] int? articoloId, [FromQuery] int? ubicazioneId,
        [FromQuery] string? lotto, [FromQuery] bool soloDisponibili = false,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
    {
        var query = db.Giacenze
            .Include(g => g.Articolo)
            .Include(g => g.Ubicazione).ThenInclude(u => u.Livello)
            .AsQueryable();

        if (articoloId.HasValue) query = query.Where(g => g.ArticoloID == articoloId);
        if (ubicazioneId.HasValue) query = query.Where(g => g.UbicazioneID == ubicazioneId);
        if (!string.IsNullOrEmpty(lotto)) query = query.Where(g => g.LottoProduzione == lotto);
        if (soloDisponibili) query = query.Where(g => g.QuantitaDisponibile > 0);

        var total = await query.CountAsync();
        var items = await query
            .OrderBy(g => g.Articolo.Codice).ThenBy(g => g.Ubicazione.Codice)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .Select(g => new GiacenzaDto(
                g.GiacenzaID, g.ArticoloID, g.Articolo.Codice, g.Articolo.Descrizione,
                g.Ubicazione.Codice, g.LottoProduzione, g.DataScadenza,
                g.QuantitaDisponibile, g.QuantitaPrenotata,
                g.QuantitaDisponibile + g.QuantitaPrenotata,
                g.QuantitaDisponibile * g.Articolo.CostoUnitario,
                g.DataScadenza != null && g.DataScadenza.Value < DateOnly.FromDateTime(DateTime.Today.AddDays(30))))
            .ToListAsync();

        return Ok(new { items, totalCount = total, page, pageSize, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
    }

    [HttpPost("load")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.ResponsabileLogistica},{Roles.OperatoreMagazzino}")]
    public async Task<IActionResult> CaricaGiacenza([FromBody] CaricGiacenzaCommand cmd)
    {
        await inventoryService.CaricGiacenzaAsync(
            cmd.ArticoloID, cmd.UbicazioneID, cmd.Quantita,
            cmd.LottoProduzione, cmd.DataScadenza, cmd.DocumentoRiferimento, cmd.TipoDocumento,
            User.Identity?.Name);
        return Ok(new { message = "Giacenza caricata con successo" });
    }

    [HttpPost("unload")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.ResponsabileLogistica},{Roles.OperatoreMagazzino}")]
    public async Task<IActionResult> ScaricoGiacenza([FromBody] ScaricoGiacenzaCommand cmd)
    {
        try
        {
            await inventoryService.ScaricoGiacenzaAsync(
                cmd.ArticoloID, cmd.UbicazioneID, cmd.Quantita,
                cmd.LottoProduzione, cmd.DocumentoRiferimento, cmd.TipoDocumento,
                User.Identity?.Name);
            return Ok(new { message = "Giacenza scaricata con successo" });
        }
        catch (InsufficientStockException ex)
        {
            return Conflict(new { code = ex.Code, message = ex.Message });
        }
    }

    [HttpPost("transfer")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.ResponsabileLogistica},{Roles.OperatoreMagazzino}")]
    public async Task<IActionResult> Trasferimento([FromBody] TrasferimentoCommand cmd)
    {
        await inventoryService.ScaricoGiacenzaAsync(
            cmd.ArticoloID, cmd.UbicazioneSorgenteID, cmd.Quantita,
            cmd.LottoProduzione, null, MovementTypes.Trasferimento, User.Identity?.Name);
        await inventoryService.CaricGiacenzaAsync(
            cmd.ArticoloID, cmd.UbicazioneDestinazioneID, cmd.Quantita,
            cmd.LottoProduzione, null, null, MovementTypes.Trasferimento, User.Identity?.Name);
        return Ok(new { message = "Trasferimento completato" });
    }

    [HttpGet("movements")]
    public async Task<IActionResult> GetMovimenti(
        [FromQuery] int? articoloId, [FromQuery] string? tipo,
        [FromQuery] DateTime? dal, [FromQuery] DateTime? al,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
    {
        var query = db.Movimenti
            .Include(m => m.Articolo)
            .Include(m => m.UbicazioneSorgente)
            .Include(m => m.UbicazioneDestinazione)
            .AsQueryable();

        if (articoloId.HasValue) query = query.Where(m => m.ArticoloID == articoloId);
        if (!string.IsNullOrEmpty(tipo)) query = query.Where(m => m.TipoMovimento == tipo);
        if (dal.HasValue) query = query.Where(m => m.DataMovimento >= dal);
        if (al.HasValue) query = query.Where(m => m.DataMovimento <= al);

        var total = await query.CountAsync();
        var items = await query
            .OrderByDescending(m => m.DataMovimento)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .Select(m => new MovimentoDto(
                m.MovimentoID, m.TipoMovimento,
                m.Articolo.Codice, m.Articolo.Descrizione,
                m.UbicazioneSorgente != null ? m.UbicazioneSorgente.Codice : null,
                m.UbicazioneDestinazione != null ? m.UbicazioneDestinazione.Codice : null,
                m.Quantita, m.LottoProduzione, m.DocumentoRiferimento,
                m.DataMovimento, m.Operatore))
            .ToListAsync();

        return Ok(new { items, totalCount = total, page, pageSize });
    }
}
