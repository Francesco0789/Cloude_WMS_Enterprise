namespace WMS.Shared.Exceptions;

public class WmsException : Exception
{
    public string Code { get; }
    public WmsException(string code, string message) : base(message) => Code = code;
}

public class InsufficientStockException : WmsException
{
    public InsufficientStockException(int articoloId, decimal requested, decimal available)
        : base("INSUFFICIENT_STOCK",
            $"Articolo {articoloId}: richiesti {requested}, disponibili {available}") { }
}

public class LocationBlockedException : WmsException
{
    public LocationBlockedException(string codice)
        : base("LOCATION_BLOCKED", $"Ubicazione {codice} è bloccata") { }
}

public class EntityNotFoundException : WmsException
{
    public EntityNotFoundException(string entity, object id)
        : base("NOT_FOUND", $"{entity} con id {id} non trovato") { }
}
