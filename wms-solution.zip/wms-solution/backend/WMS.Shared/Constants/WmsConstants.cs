namespace WMS.Shared.Constants;

public static class OrderStates
{
    public const string Bozza = "BOZZA";
    public const string Confermato = "CONFERMATO";
    public const string InPicking = "IN_PICKING";
    public const string Pronto = "PRONTO";
    public const string Spedito = "SPEDITO";
    public const string Consegnato = "CONSEGNATO";
    public const string Annullato = "ANNULLATO";
}

public static class MovementTypes
{
    public const string Carico = "CARICO";
    public const string Scarico = "SCARICO";
    public const string Trasferimento = "TRASFERIMENTO";
    public const string Rettifica = "RETTIFICA";
    public const string PrelievoPickng = "PRELIEVO_PICKING";
    public const string Reintegro = "REINTEGRO";
}

public static class AreaTypes
{
    public const string Picking = "PICKING";
    public const string Stoccaggio = "STOCCAGGIO";
    public const string Staging = "STAGING";
    public const string Spedizione = "SPEDIZIONE";
    public const string Ricezione = "RICEZIONE";
    public const string Quarantena = "QUARANTENA";
}

public static class CacheKeys
{
    public const string WarehouseMap = "wms:warehouse:map:{0}";
    public const string InventoryKpi = "wms:inventory:kpi";
    public const string FreeLocations = "wms:locations:free:{0}:{1}";
}

public static class Roles
{
    public const string Admin = "Admin";
    public const string ResponsabileLogistica = "ResponsabileLogistica";
    public const string OperatoreMagazzino = "OperatoreMagazzino";
    public const string Viewer = "Viewer";
}
