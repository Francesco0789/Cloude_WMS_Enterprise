namespace WMS.Application.Shipping.Dtos;

public record SpedizioneDto(
    int SpedizioneID,
    string NumeroSpedizione,
    int VettoreID,
    string NomeVettore,
    DateTime? DataSpedizione,
    DateTime? DataConsegnaPrevista,
    DateTime? DataConsegnaEffettiva,
    string Stato,
    string? NumeroTracking,
    decimal? PesoTotaleKg,
    int? NumeroColli,
    string? IndirizzoDestinatario);

public record CreaSpedizioneCommand(
    int VettoreID,
    DateTime? DataSpedizione,
    DateTime? DataConsegnaPrevista,
    string? IndirizzoDestinatario,
    string? Note,
    List<int> OrdiniVenditaIds);

public record AggiornaTrackingCommand(
    int SpedizioneID,
    string? NumeroTracking,
    string Stato,
    DateTime? DataConsegnaEffettiva);
