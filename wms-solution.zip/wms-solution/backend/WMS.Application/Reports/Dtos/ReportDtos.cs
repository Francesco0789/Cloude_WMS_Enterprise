namespace WMS.Application.Reports.Dtos;

public record KpiGiacenzeDto(
    string CodiceArticolo,
    string Articolo,
    string Magazzino,
    string Ubicazione,
    string? Lotto,
    DateOnly? DataScadenza,
    decimal QuantitaDisponibile,
    decimal QuantitaPrenotata,
    decimal ValoreStockDisponibile,
    bool InScadenzaBreve);

public record DashboardKpiDto(
    int OrdiniAperti,
    int PalletInEntrata,
    int SpedzioniOggi,
    decimal ValoreTotaleStock,
    int ArticoliSottoScortaMinima,
    int ArticoliInScadenza,
    List<SaturazioneAreaDto> SaturazioneAree);

public record SaturazioneAreaDto(
    string CodiceArea,
    string DescrizioneArea,
    int CapacitaTotale,
    int CapacitaOccupata,
    decimal PercentualeSaturazione);
