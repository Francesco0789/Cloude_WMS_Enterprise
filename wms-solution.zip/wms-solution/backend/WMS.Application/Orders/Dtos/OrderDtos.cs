namespace WMS.Application.Orders.Dtos;

public record OrdineVenditaDto(
    int OrdineVenditaID,
    string NumeroOrdine,
    int ClienteID,
    string RagioneSocialeCliente,
    DateOnly DataOrdine,
    DateOnly? DataConsegnaPrevista,
    byte Priorita,
    string Stato,
    string? IndirizzoSpedizione,
    decimal ImponibileRighe,
    decimal CostoSpedizione,
    decimal ScontoGlobale,
    decimal CostoTotale,
    List<RigaOrdineVenditaDto> Righe);

public record RigaOrdineVenditaDto(
    int RigaID,
    int ArticoloID,
    string CodiceArticolo,
    string DescrizioneArticolo,
    decimal QuantitaOrdinata,
    decimal QuantitaPrelevata,
    decimal PrezzoUnitario,
    decimal Sconto,
    decimal ImportoRiga,
    string StatoRiga);

public record CreaOrdineVenditaCommand(
    int ClienteID,
    DateOnly? DataConsegnaPrevista,
    byte Priorita,
    string? IndirizzoSpedizione,
    string? Note,
    decimal CostoSpedizione,
    decimal ScontoGlobale,
    List<CreaRigaOrdineCommand> Righe);

public record CreaRigaOrdineCommand(
    int ArticoloID,
    decimal QuantitaOrdinata,
    decimal PrezzoUnitario,
    decimal Sconto);

public record OrdineListItemDto(
    int OrdineVenditaID,
    string NumeroOrdine,
    string RagioneSocialeCliente,
    DateOnly DataOrdine,
    DateOnly? DataConsegnaPrevista,
    byte Priorita,
    string Stato,
    decimal CostoTotale,
    int NumeroRighe);

public record PagedResult<T>(
    IEnumerable<T> Items,
    int TotalCount,
    int Page,
    int PageSize,
    int TotalPages);
