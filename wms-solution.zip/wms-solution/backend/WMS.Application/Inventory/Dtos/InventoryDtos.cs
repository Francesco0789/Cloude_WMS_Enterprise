namespace WMS.Application.Inventory.Dtos;

public record GiacenzaDto(
    int GiacenzaID,
    int ArticoloID,
    string CodiceArticolo,
    string DescrizioneArticolo,
    string CodiceUbicazione,
    string? LottoProduzione,
    DateOnly? DataScadenza,
    decimal QuantitaDisponibile,
    decimal QuantitaPrenotata,
    decimal QuantitaTotale,
    decimal ValoreDisponibile,
    bool InScadenzaBreve);

public record CaricGiacenzaCommand(
    int ArticoloID,
    int UbicazioneID,
    decimal Quantita,
    string? LottoProduzione,
    DateOnly? DataScadenza,
    string? DocumentoRiferimento,
    string? TipoDocumento);

public record ScaricoGiacenzaCommand(
    int ArticoloID,
    int UbicazioneID,
    decimal Quantita,
    string? LottoProduzione,
    string? DocumentoRiferimento,
    string? TipoDocumento);

public record TrasferimentoCommand(
    int ArticoloID,
    int UbicazioneSorgenteID,
    int UbicazioneDestinazioneID,
    decimal Quantita,
    string? LottoProduzione);

public record MovimentoDto(
    int MovimentoID,
    string TipoMovimento,
    string CodiceArticolo,
    string DescrizioneArticolo,
    string? UbicazioneSorgente,
    string? UbicazioneDestinazione,
    decimal Quantita,
    string? LottoProduzione,
    string? DocumentoRiferimento,
    DateTime DataMovimento,
    string? Operatore);
