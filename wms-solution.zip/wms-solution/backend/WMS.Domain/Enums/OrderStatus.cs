namespace WMS.Domain.Enums;

public enum OrderStatus
{
    Bozza,
    Confermato,
    InPicking,
    Pronto,
    Spedito,
    Consegnato,
    Annullato
}

public enum PurchaseOrderStatus
{
    Bozza,
    Confermato,
    Parziale,
    Evaso,
    Annullato
}

public enum ShipmentStatus
{
    Bozza,
    Pronta,
    InTransito,
    Consegnata,
    Reso,
    Problema
}

public enum MovementType
{
    Carico,
    Scarico,
    Trasferimento,
    Rettifica,
    PrelievoPickig,
    Reintegro,
    Inventario
}

public enum QualityStatus
{
    Accettato,
    InQuarantena,
    Rifiutato
}

public enum LocationType
{
    Standard,
    Pallet,
    Picking,
    Bulk,
    Frigorifero
}

public enum LogisticsRequestType
{
    Produzione,
    Vendita,
    Trasferimento,
    Altro
}
