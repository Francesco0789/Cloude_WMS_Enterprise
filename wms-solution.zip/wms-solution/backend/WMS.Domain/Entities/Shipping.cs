namespace WMS.Domain.Entities;

public class Vettore
{
    public int VettoreID { get; set; }
    public string Codice { get; set; } = default!;
    public string RagioneSociale { get; set; } = default!;
    public string? Email { get; set; }
    public string? Telefono { get; set; }
    public string? PortaleTracking { get; set; }
    public bool Attivo { get; set; } = true;
}

public class Spedizione
{
    public int SpedizioneID { get; set; }
    public string NumeroSpedizione { get; set; } = default!;
    public int VettoreID { get; set; }
    public Vettore Vettore { get; set; } = default!;
    public DateTime? DataSpedizione { get; set; }
    public DateTime? DataConsegnaPrevista { get; set; }
    public DateTime? DataConsegnaEffettiva { get; set; }
    public string Stato { get; set; } = "BOZZA";
    public string? NumeroTracking { get; set; }
    public decimal? PesoTotaleKg { get; set; }
    public int? NumeroColli { get; set; }
    public int? NumeroPallet { get; set; }
    public string? IndirizzoDestinatario { get; set; }
    public string? Note { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public ICollection<RigaSpedizione> Righe { get; set; } = [];
}

public class RigaSpedizione
{
    public int RigaSpedizioneID { get; set; }
    public int SpedizioneID { get; set; }
    public Spedizione Spedizione { get; set; } = default!;
    public int? OrdineVenditaID { get; set; }
    public int? ColloID { get; set; }
    public int? PalletID { get; set; }
    public int? ArticoloID { get; set; }
    public decimal? Quantita { get; set; }
    public string? Note { get; set; }
}
