namespace WMS.Domain.Entities;

public class Magazzino
{
    public int MagazzinoID { get; set; }
    public string Codice { get; set; } = default!;
    public string Descrizione { get; set; } = default!;
    public string? Indirizzo { get; set; }
    public bool Attivo { get; set; } = true;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public ICollection<Area> Aree { get; set; } = [];
}

public class Area
{
    public int AreaID { get; set; }
    public int MagazzinoID { get; set; }
    public Magazzino Magazzino { get; set; } = default!;
    public string Codice { get; set; } = default!;
    public string Descrizione { get; set; } = default!;
    public string TipoArea { get; set; } = default!;
    public bool Attivo { get; set; } = true;
    public ICollection<Corsia> Corsie { get; set; } = [];
}

public class Corsia
{
    public int CorsiaID { get; set; }
    public int AreaID { get; set; }
    public Area Area { get; set; } = default!;
    public string Codice { get; set; } = default!;
    public string? Descrizione { get; set; }
    public ICollection<Scaffale> Scaffali { get; set; } = [];
}

public class Scaffale
{
    public int ScaffaleID { get; set; }
    public int CorsiaID { get; set; }
    public Corsia Corsia { get; set; } = default!;
    public string Codice { get; set; } = default!;
    public ICollection<Livello> Livelli { get; set; } = [];
}

public class Livello
{
    public int LivelloID { get; set; }
    public int ScaffaleID { get; set; }
    public Scaffale Scaffale { get; set; } = default!;
    public string Codice { get; set; } = default!;
    public decimal? AltezzaMin { get; set; }
    public decimal? AltezzaMax { get; set; }
    public ICollection<Ubicazione> Ubicazioni { get; set; } = [];
}

public class Ubicazione
{
    public int UbicazioneID { get; set; }
    public int LivelloID { get; set; }
    public Livello Livello { get; set; } = default!;
    public string Codice { get; set; } = default!;
    public string? Descrizione { get; set; }
    public string TipoUbicazione { get; set; } = "STANDARD";
    public short CapacitaPallet { get; set; } = 1;
    public decimal? CapacitaKg { get; set; }
    public decimal? CapacitaM3 { get; set; }
    public bool Bloccata { get; set; } = false;
    public string? MotivoBloccata { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public ICollection<Giacenza> Giacenze { get; set; } = [];
}
