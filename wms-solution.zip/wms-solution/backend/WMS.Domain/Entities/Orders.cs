namespace WMS.Domain.Entities;

public class Fornitore
{
    public int FornitoreID { get; set; }
    public string Codice { get; set; } = default!;
    public string RagioneSociale { get; set; } = default!;
    public string? PartitaIVA { get; set; }
    public string? Email { get; set; }
    public string? Telefono { get; set; }
    public bool Attivo { get; set; } = true;
}

public class Cliente
{
    public int ClienteID { get; set; }
    public string Codice { get; set; } = default!;
    public string RagioneSociale { get; set; } = default!;
    public string? PartitaIVA { get; set; }
    public string? Email { get; set; }
    public string? Telefono { get; set; }
    public string? IndirizzoSpedizione { get; set; }
    public bool Attivo { get; set; } = true;
}

public class OrdineVendita
{
    public int OrdineVenditaID { get; set; }
    public string NumeroOrdine { get; set; } = default!;
    public int ClienteID { get; set; }
    public Cliente Cliente { get; set; } = default!;
    public DateOnly DataOrdine { get; set; }
    public DateOnly? DataConsegnaPrevista { get; set; }
    public byte Priorita { get; set; } = 5;
    public string Stato { get; set; } = "BOZZA";
    public string? IndirizzoSpedizione { get; set; }
    public string? Note { get; set; }
    public decimal CostoSpedizione { get; set; }
    public decimal ScontoGlobale { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public ICollection<RigaOrdineVendita> Righe { get; set; } = [];

    public decimal ImponibileRighe => Righe.Sum(r => r.ImportoRiga);
    public decimal CostoTotale => ImponibileRighe * (1 - ScontoGlobale / 100) + CostoSpedizione;
}

public class RigaOrdineVendita
{
    public int RigaOrdineVenditaID { get; set; }
    public int OrdineVenditaID { get; set; }
    public OrdineVendita OrdineVendita { get; set; } = default!;
    public int ArticoloID { get; set; }
    public Articolo Articolo { get; set; } = default!;
    public decimal QuantitaOrdinata { get; set; }
    public decimal QuantitaPrelevata { get; set; }
    public decimal QuantitaSpedita { get; set; }
    public decimal PrezzoUnitario { get; set; }
    public decimal Sconto { get; set; }
    public string StatoRiga { get; set; } = "APERTA";
    public decimal ImportoRiga => QuantitaOrdinata * PrezzoUnitario * (1 - Sconto / 100);
}

public class EntrataMerce
{
    public int EntrataMerceID { get; set; }
    public string NumeroDocumento { get; set; } = default!;
    public int? OrdineAcquistoID { get; set; }
    public int FornitoreID { get; set; }
    public Fornitore Fornitore { get; set; } = default!;
    public DateTime DataEntrata { get; set; }
    public string? DDT_Numero { get; set; }
    public DateOnly? DDT_Data { get; set; }
    public string Stato { get; set; } = "IN_CORSO";
    public string? Note { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public ICollection<Pallet> Pallet { get; set; } = [];
}
