namespace WMS.Domain.Entities;

public class Articolo
{
    public int ArticoloID { get; set; }
    public string Codice { get; set; } = default!;
    public string? Barcode { get; set; }
    public string Descrizione { get; set; } = default!;
    public string? DescrizioneBreve { get; set; }
    public string UnitaMisura { get; set; } = "PZ";
    public decimal? PesoUnitarioKg { get; set; }
    public decimal? VolumeM3 { get; set; }
    public decimal CostoUnitario { get; set; }
    public decimal PrezzoVendita { get; set; }
    public string? CodiceCategoria { get; set; }
    public decimal ScortaMinima { get; set; }
    public decimal? ScortaMassima { get; set; }
    public int GiorniLeadTime { get; set; }
    public bool Attivo { get; set; } = true;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public ICollection<Giacenza> Giacenze { get; set; } = [];
}

public class Giacenza
{
    public int GiacenzaID { get; set; }
    public int ArticoloID { get; set; }
    public Articolo Articolo { get; set; } = default!;
    public int UbicazioneID { get; set; }
    public Ubicazione Ubicazione { get; set; } = default!;
    public string? LottoProduzione { get; set; }
    public DateOnly? DataScadenza { get; set; }
    public decimal QuantitaDisponibile { get; set; }
    public decimal QuantitaPrenotata { get; set; }
    public decimal QuantitaTotale => QuantitaDisponibile + QuantitaPrenotata;
    public DateTime UltimoAggiornamento { get; set; }
}

public class Movimento
{
    public int MovimentoID { get; set; }
    public string TipoMovimento { get; set; } = default!;
    public int ArticoloID { get; set; }
    public Articolo Articolo { get; set; } = default!;
    public int? UbicazioneSorgenteID { get; set; }
    public Ubicazione? UbicazioneSorgente { get; set; }
    public int? UbicazioneDestinazioneID { get; set; }
    public Ubicazione? UbicazioneDestinazione { get; set; }
    public int? PalletID { get; set; }
    public decimal Quantita { get; set; }
    public string? LottoProduzione { get; set; }
    public DateOnly? DataScadenza { get; set; }
    public string? DocumentoRiferimento { get; set; }
    public string? TipoDocumento { get; set; }
    public string? Note { get; set; }
    public DateTime DataMovimento { get; set; }
    public string? Operatore { get; set; }
    public bool Confermato { get; set; } = true;
}

public class Pallet
{
    public int PalletID { get; set; }
    public string CodicePallet { get; set; } = default!;
    public int? EntrataMerceID { get; set; }
    public int? UbicazioneID { get; set; }
    public Ubicazione? Ubicazione { get; set; }
    public string Stato { get; set; } = "DISPONIBILE";
    public decimal? PesoKg { get; set; }
    public DateTime DataCreazione { get; set; }
    public string? CreatedBy { get; set; }
    public ICollection<Collo> Colli { get; set; } = [];
}

public class Collo
{
    public int ColloID { get; set; }
    public string CodiceCollo { get; set; } = default!;
    public int? PalletID { get; set; }
    public Pallet? Pallet { get; set; }
    public int ArticoloID { get; set; }
    public Articolo Articolo { get; set; } = default!;
    public decimal Quantita { get; set; }
    public string? LottoProduzione { get; set; }
    public DateOnly? DataScadenza { get; set; }
    public decimal? PesoKg { get; set; }
    public string Stato { get; set; } = "DISPONIBILE";
}
