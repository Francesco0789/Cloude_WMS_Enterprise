namespace WMS.Domain.Interfaces;

public interface IInventoryService
{
    Task<int> ScaricoGiacenzaAsync(int articoloId, int ubicazioneId, decimal quantita,
        string? lotto = null, string? documentoRif = null, string? tipoDoc = null,
        string? operatore = null, CancellationToken ct = default);

    Task CaricGiacenzaAsync(int articoloId, int ubicazioneId, decimal quantita,
        string? lotto = null, DateOnly? dataScadenza = null, string? documentoRif = null,
        string? tipoDoc = null, string? operatore = null, CancellationToken ct = default);
}

public interface IWarehouseRepository
{
    Task<IEnumerable<Domain.Entities.Magazzino>> GetAllActiveAsync(CancellationToken ct = default);
    Task<Domain.Entities.Ubicazione?> GetByCodeAsync(string codice, CancellationToken ct = default);
    Task<IEnumerable<Domain.Entities.Ubicazione>> GetFreeLocationsAsync(int magazzinoId, string tipo, CancellationToken ct = default);
}

public interface IOrderRepository
{
    Task<Domain.Entities.OrdineVendita?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<IEnumerable<Domain.Entities.OrdineVendita>> GetPagedAsync(int page, int pageSize, string? stato = null, CancellationToken ct = default);
    Task<int> CreateAsync(Domain.Entities.OrdineVendita order, CancellationToken ct = default);
    Task UpdateAsync(Domain.Entities.OrdineVendita order, CancellationToken ct = default);
}
