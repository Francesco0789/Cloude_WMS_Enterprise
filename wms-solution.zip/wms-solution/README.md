# WMS Enterprise

Sistema di gestione magazzino enterprise-grade.  
**Frontend**: React 18 + TypeScript → Deploy Vercel  
**Backend**: .NET 8 ASP.NET Core → Deploy Railway  
**Database**: SQL Server 2022

---

## Struttura repository

```
wms-solution/
├── backend/            # Solution .NET 8
│   ├── WMS.API/        # Controller, Program.cs, Middleware
│   ├── WMS.Application/# DTOs, Commands, Queries
│   ├── WMS.Domain/     # Entità, Interfacce, Enums
│   ├── WMS.Infrastructure/ # DbContext, Services, Hangfire
│   ├── WMS.Shared/     # Costanti, Eccezioni
│   ├── WMS.sln
│   └── Dockerfile
├── frontend/           # React + Vite + Tailwind
│   ├── src/
│   │   ├── app/        # App.tsx, globals.css
│   │   ├── components/ # Sidebar, Topbar, UI base
│   │   ├── features/   # Dashboard, Ordini, Giacenze, etc.
│   │   ├── lib/        # apiClient, mockData
│   │   ├── mock/       # Dati demo per Vercel preview
│   │   └── types/      # TypeScript interfaces
│   ├── vercel.json
│   └── Dockerfile
├── docker/
│   └── docker-compose.yml   # Sviluppo locale completo
└── .github/workflows/
    └── deploy.yml           # CI/CD GitHub Actions
```

---

## Avvio rapido (sviluppo locale)

```bash
# 1. Clone
git clone <repo-url> && cd wms-solution

# 2. Avvia tutto con Docker Compose
cd docker
docker-compose up -d

# Frontend → http://localhost:5173
# Backend API → http://localhost:5000
# Swagger → http://localhost:5000/swagger
# SQL Server → localhost:1433

# 3. Applica il DDL del database
# Apri SQL Server Management Studio → connettiti a localhost,1433
# SA / Wms_Dev_Pass1!
# Esegui: WMS_SQLServer_DDL.sql
```

---

## Deploy Vercel (solo frontend con mock)

```bash
cd frontend

# 1. Installa Vercel CLI
npm i -g vercel

# 2. Deploy (usa mock data — nessun backend necessario)
vercel --env VITE_USE_MOCK=true --env VITE_API_URL=https://placeholder.railway.app/api/v1

# 3. Configura il progetto su vercel.com → aggiungi le env vars
```

---

## Deploy Railway (backend)

```bash
# 1. Crea account Railway → railway.app
# 2. Installa CLI
npm i -g @railway/cli

# 3. Login e nuovo progetto
railway login
railway init

# 4. Deploy backend
cd backend
railway up --service wms-api

# 5. Aggiungi SQL Server come Plugin in Railway dashboard
# 6. Copia la connection string → aggiungi come env var:
#    ConnectionStrings__WMS = <railway_sqlserver_url>
#    Jwt__Secret = <generare stringa random 32+ chars>
```

---

## Secrets GitHub Actions

| Secret | Descrizione |
|---|---|
| `RAILWAY_TOKEN` | Token Railway per deploy backend |
| `VERCEL_TOKEN` | Token Vercel per deploy frontend |
| `VERCEL_ORG_ID` | ID organizzazione Vercel |
| `VERCEL_PROJECT_ID` | ID progetto Vercel |
| `VITE_API_URL` | URL produzione API Railway |

---

## Stack completo

| Layer | Tecnologia |
|---|---|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS |
| State/Query | TanStack Query v5 |
| Routing | React Router v6 |
| Charts | Recharts |
| Backend | .NET 8, ASP.NET Core Web API |
| ORM | Entity Framework Core 8 |
| Database | SQL Server 2022 |
| Cache | Redis (opzionale) |
| Jobs | Hangfire |
| Real-time | SignalR |
| Auth | JWT Bearer |
| CI/CD | GitHub Actions |
| Deploy FE | Vercel |
| Deploy BE | Railway |
